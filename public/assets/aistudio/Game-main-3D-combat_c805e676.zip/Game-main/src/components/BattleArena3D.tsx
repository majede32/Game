import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { BattleMonster, ElementType } from '../types/game';

interface Props {
  playerMonsters: BattleMonster[];
  enemyMonsters: BattleMonster[];
  activeTurnMonsterId: string;
  selectedTargetId: string;
  attackingMonsterId: string | null;
  hitMonsterId: string | null;
  activeVfx: { key: string; targetId: string; attackerId: string } | null;
  floatingTexts: { id: string; targetMonsterId: string; text: string; color: string; isCrit?: boolean }[];
  onSelectTarget: (id: string) => void;
}

const ELEMENT: Record<ElementType, number> = {
  fire: 0xff572e, earth: 0x9b7950, water: 0x36bde8,
  dark: 0x9c63dc, nature: 0x65c65a, thunder: 0xf5d442,
};

function material(color: number, roughness = 0.58, metalness = 0.08) {
  return new THREE.MeshStandardMaterial({ color, roughness, metalness });
}
function addMesh(parent: THREE.Group, geometry: THREE.BufferGeometry, mat: THREE.Material, x: number, y: number, z: number, sx=1, sy=1, sz=1) {
  const mesh = new THREE.Mesh(geometry, mat);
  mesh.position.set(x,y,z); mesh.scale.set(sx,sy,sz); mesh.castShadow = true; mesh.receiveShadow = true; parent.add(mesh); return mesh;
}

// Procedural low-poly creature: real 3D geometry, not a flat image or billboard.
function makeCreature(bm: BattleMonster) {
  const root = new THREE.Group();
  const e = bm.monster.element;
  const color = ELEMENT[e] || ELEMENT.fire;
  const skin = material(color, 0.48, 0.12);
  const dark = material(new THREE.Color(color).multiplyScalar(0.48).getHex());
  const horn = material(e === 'fire' ? 0xffd08a : e === 'water' ? 0xb8f1ff : 0xd8d2c5, 0.35, 0.18);
  const belly = material(new THREE.Color(color).lerp(new THREE.Color(0xffffff), 0.38).getHex());
  const sphere = new THREE.SphereGeometry(1, 18, 12);
  const cone = new THREE.ConeGeometry(0.22, 0.72, 7);
  // broad torso and chest
  addMesh(root, sphere, skin, 0, 1.05, 0, 0.72, 0.88, 0.56);
  addMesh(root, sphere, belly, 0.38, 1.12, 0, 0.34, 0.52, 0.43);
  // head projects toward the opponent (+X in local space)
  addMesh(root, sphere, skin, 0.57, 1.88, 0, 0.48, 0.48, 0.45);
  addMesh(root, sphere, dark, 0.88, 1.72, 0, 0.38, 0.22, 0.34);
  const eyeMat = new THREE.MeshStandardMaterial({ color: 0xfff4c2, emissive: 0xffa52c, emissiveIntensity: 0.8 });
  addMesh(root, sphere, eyeMat, 0.82, 1.98, 0.34, 0.075, 0.075, 0.055);
  addMesh(root, sphere, eyeMat, 0.82, 1.98, -0.34, 0.075, 0.075, 0.055);
  // legs and arms
  for (const z of [-0.34, 0.34]) {
    addMesh(root, sphere, dark, -0.2, 0.43, z, 0.23, 0.48, 0.22);
    addMesh(root, sphere, skin, 0.15, 1.12, z * 1.65, 0.25, 0.55, 0.2).rotation.z = -0.35;
  }
  // species silhouettes
  if (e === 'fire' || e === 'dark') {
    for (let i=0;i<3;i++) addMesh(root, cone, i===1?horn:dark, -0.35-i*0.18, 1.82+i*0.2, 0, 0.85, 0.9, 0.85).rotation.z = Math.PI/2;
    const tail = addMesh(root, cone, e==='fire'?horn:dark, -0.82, 0.75, 0, 0.8, 1.8, 0.8); tail.rotation.z = -Math.PI/2;
    for (const z of [-0.48,0.48]) { const wing=addMesh(root, new THREE.ConeGeometry(0.55,1.15,5), dark, -0.18,1.75,z,1,1,0.22); wing.rotation.z = Math.PI/2.8; }
  } else if (e === 'earth') {
    for(let i=0;i<5;i++) { const spike=addMesh(root, cone, horn, -0.48+i*0.23, 1.75+(i%2)*0.28, 0, 0.9,1.15,0.9); spike.rotation.z=-Math.PI/2; }
    addMesh(root, sphere, dark, -0.55,1.05,0,0.35,0.72,0.62);
  } else if (e === 'water') {
    for (const z of [-0.3,0.3]) { const fin=addMesh(root, cone, horn, -0.2,1.55,z,0.7,1.5,0.65); fin.rotation.z=Math.PI/2; }
    addMesh(root, new THREE.TorusGeometry(0.42,0.09,8,18), horn, -0.75,0.85,0,1,1,1).rotation.y=Math.PI/2;
  } else if (e === 'thunder') {
    for(let i=0;i<2;i++) { const spike=addMesh(root, cone, horn, -0.2+i*0.35,2.25, i?0.28:-0.28,0.65,1.2,0.65); spike.rotation.z=Math.PI; }
  } else {
    for(let i=0;i<3;i++) { const leaf=addMesh(root, cone, belly, -0.45+i*0.32,1.65, i%2?0.35:-0.35,0.8,1.4,0.7); leaf.rotation.z=Math.PI/2; }
  }
  // feet claws
  for (const z of [-0.35,0.35]) addMesh(root, cone, horn, 0.12,0.12,z,0.45,0.6,0.55).rotation.z=-Math.PI/2;
  root.userData.body = root.children[0];
  root.userData.element = e;
  return root;
}

export const BattleArena3D: React.FC<Props> = ({ playerMonsters, enemyMonsters, activeTurnMonsterId, selectedTargetId, attackingMonsterId, hitMonsterId, activeVfx, floatingTexts, onSelectTarget }) => {
  const hostRef = useRef<HTMLDivElement>(null);
  const objectsRef = useRef<Map<string, THREE.Group>>(new Map());
  const [ready, setReady] = useState(false);
  const all = [...playerMonsters, ...enemyMonsters];
  const latestRef = useRef({ all, activeTurnMonsterId, attackingMonsterId, hitMonsterId });
  latestRef.current = { all, activeTurnMonsterId, attackingMonsterId, hitMonsterId };

  useEffect(() => {
    const host = hostRef.current; if (!host) return;
    let renderer: THREE.WebGLRenderer;
    try { renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true }); }
    catch { setReady(false); return; }
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.7));
    renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.setSize(host.clientWidth, host.clientHeight); host.appendChild(renderer.domElement);
    const scene = new THREE.Scene(); scene.background = new THREE.Color(0x111827); scene.fog = new THREE.Fog(0x111827, 18, 34);
    const camera = new THREE.PerspectiveCamera(34, host.clientWidth/host.clientHeight, 0.1, 100);
    camera.position.set(0, 7.8, 22); camera.lookAt(0, 1.3, 0);
    scene.add(new THREE.HemisphereLight(0x9ecbff, 0x24182b, 2.1));
    const key = new THREE.DirectionalLight(0xffd6a0, 3.2); key.position.set(-5,11,8); key.castShadow=true; scene.add(key);
    const rim = new THREE.PointLight(0x4c8dff, 65, 24); rim.position.set(5,5,-5); scene.add(rim);
    const floor = new THREE.Mesh(new THREE.CircleGeometry(10,64), material(0x343344,0.82,0.12));
    floor.rotation.x=-Math.PI/2; floor.position.y=-0.03; floor.scale.set(1.25,0.7,1); floor.receiveShadow=true; scene.add(floor);
    const arena = new THREE.Mesh(new THREE.TorusGeometry(8.1,0.16,12,80), new THREE.MeshStandardMaterial({color:0xc18b42,metalness:0.72,roughness:0.3,emissive:0x3c2108}));
    arena.rotation.x=Math.PI/2; arena.position.y=0.08; arena.scale.set(1.25,0.7,1); scene.add(arena);
    for(let i=0;i<18;i++){ const a=i/18*Math.PI*2; const pillar=new THREE.Mesh(new THREE.CylinderGeometry(0.22,0.32,3.8,7),material(0x55516a)); pillar.position.set(Math.cos(a)*10,1.8,Math.sin(a)*6); scene.add(pillar); }
    const grid = new THREE.GridHelper(18,30,0x7c5b37,0x39334a); grid.position.y=0.02; grid.scale.set(1.2,1,0.7); scene.add(grid);
    const groups = new Map<string, THREE.Group>();
    all.forEach((bm)=>{
      const g=makeCreature(bm); const side=bm.isAi?1:-1; const lane=bm.position-1;
      g.position.set(side*(3.7+Math.abs(lane)*0.18),0,lane*2.15);
      g.rotation.y=bm.isAi?Math.PI:0; g.scale.setScalar(bm.isDefeated?0.001:1);
      scene.add(g); groups.set(bm.monster.id,g);
      const ring=new THREE.Mesh(new THREE.TorusGeometry(0.88,0.055,8,36),new THREE.MeshBasicMaterial({color:ELEMENT[bm.monster.element],transparent:true,opacity:0.8}));
      ring.rotation.x=Math.PI/2; ring.position.y=0.12; g.add(ring);
    });
    objectsRef.current=groups; setReady(true);
    let raf=0; const clock=new THREE.Clock();
    const animate=()=>{ raf=requestAnimationFrame(animate); const t=clock.getElapsedTime();
      const latest=latestRef.current;
      groups.forEach((g,id)=>{ const bm=latest.all.find(x=>x.monster.id===id); if(!bm)return;
        const active=id===latest.activeTurnMonsterId; const attack=id===latest.attackingMonsterId; const hit=id===latest.hitMonsterId;
        const defeated=bm.isDefeated; const baseX=(bm.isAi?1:-1)*(3.7+Math.abs(bm.position-1)*0.18);
        g.position.y=defeated?-0.48:Math.sin(t*2.1+bm.position)*0.07+(active?Math.sin(t*4)*0.08:0);
        g.position.x=baseX+(attack?(bm.isAi?-1:1)*1.45*Math.sin(Math.min(1,(t%0.8)/0.8*Math.PI)):0)+(hit?(bm.isAi?0.18:-0.18)*Math.sin(t*38):0);
        g.rotation.z=attack?Math.sin(t*12)*0.14:hit?Math.sin(t*34)*0.08:Math.sin(t*1.4)*0.018;
        g.scale.setScalar(defeated?0.72:hit?1.04:active?1.04:1);
        g.traverse(o=>{if((o as THREE.Mesh).isMesh){const m=(o as THREE.Mesh).material as THREE.MeshStandardMaterial; if(m.emissive){m.emissive.set(hit?0xff2411:active?ELEMENT[bm.monster.element]:0x000000);m.emissiveIntensity=hit?1.5:active?0.16:0;}}});
      });
      renderer.render(scene,camera);
    }; animate();
    const resize=()=>{if(!host.isConnected)return; camera.aspect=host.clientWidth/host.clientHeight;camera.updateProjectionMatrix();renderer.setSize(host.clientWidth,host.clientHeight);};
    const observer=new ResizeObserver(resize); observer.observe(host);
    return ()=>{cancelAnimationFrame(raf);observer.disconnect();groups.forEach(g=>{scene.remove(g);g.traverse(o=>{if((o as THREE.Mesh).geometry)o.geometry.dispose();});});renderer.dispose();renderer.domElement.remove();objectsRef.current.clear();};
  // Scene models are created when a battle starts; health/turn animation is read in the render loop.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [inActiveBattleKey(playerMonsters,enemyMonsters)]);

  const floatingFor=(id:string)=>floatingTexts.filter(x=>x.targetMonsterId===id);
  return <div className="relative w-full h-[470px] sm:h-[540px] rounded-2xl overflow-hidden border border-amber-900/60 bg-slate-950 shadow-[inset_0_0_80px_rgba(2,6,23,.9)]">
    <div ref={hostRef} className="absolute inset-0" />
    {!ready && <div className="absolute inset-0 grid place-items-center text-amber-200 text-sm">يتعذر تشغيل WebGL على هذا الجهاز</div>}
    <div className="absolute inset-x-0 top-0 flex justify-between p-3 pointer-events-none">
      <span className="rounded-lg bg-blue-950/80 border border-blue-400/30 px-3 py-1 text-xs font-black text-blue-200">فريقك</span>
      <span className="rounded-lg bg-red-950/80 border border-red-400/30 px-3 py-1 text-xs font-black text-red-200">الخصم</span>
    </div>
    <div className="absolute inset-x-0 bottom-2 flex justify-between gap-2 px-2 items-end">
      {[playerMonsters,enemyMonsters].map((team,side)=><div key={side} className={`flex flex-1 gap-1 ${side?'justify-end':'justify-start'}`}>
        {team.map(bm=>{const hp=Math.max(0,bm.currentHp/bm.monster.maxHp*100);return <button key={bm.monster.id} onClick={()=>bm.isAi&&!bm.isDefeated&&onSelectTarget(bm.monster.id)} className={`min-w-0 w-[31%] rounded-lg border p-1.5 text-left backdrop-blur-md transition-all ${selectedTargetId===bm.monster.id?'border-red-400 bg-red-950/80 ring-2 ring-red-500/40':'border-white/15 bg-slate-950/75'} ${bm.isDefeated?'opacity-35':''}`}>
          <div className="flex justify-between gap-1 text-[10px] font-bold text-white"><span className="truncate">{bm.monster.nameAr}</span><span>Lv{bm.monster.level}</span></div>
          <div className="h-1.5 bg-slate-700 rounded-full mt-1 overflow-hidden"><div className={`h-full ${hp>50?'bg-emerald-400':hp>20?'bg-amber-400':'bg-red-500'}`} style={{width:`${hp}%`}}/></div>
          <div className="text-[9px] text-slate-300 mt-0.5">{bm.currentHp}/{bm.monster.maxHp}</div>
          {floatingFor(bm.monster.id).slice(-1).map(f=><div key={f.id} className="text-[10px] font-black text-amber-300">{f.text}</div>)}
        </button>})}
      </div>)}
    </div>
    {activeVfx&&<div key={activeVfx.key+activeVfx.attackerId} className="absolute inset-0 pointer-events-none overflow-hidden">
      <div className={`absolute left-1/2 top-1/2 w-20 h-20 rounded-full blur-xl animate-ping ${activeVfx.key.includes('fire')||activeVfx.key.includes('meteor')?'bg-orange-400/70':activeVfx.key.includes('water')?'bg-cyan-300/70':activeVfx.key.includes('dark')?'bg-purple-500/70':'bg-amber-300/70'}`}/>
      <div className="absolute inset-0 bg-white/5 animate-pulse"/>
    </div>}
  </div>;
};

function inActiveBattleKey(p: BattleMonster[], e: BattleMonster[]) { return [...p,...e].map(x=>x.monster.id).join('|'); }
